package day12;

public class Car extends vehicel {
	void methoddrive()
	{
		System.out.println("Car is driving");
	}
}
