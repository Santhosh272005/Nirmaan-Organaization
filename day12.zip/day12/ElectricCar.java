package day12;

public class ElectricCar extends Car{
	void chargebattery() 
	{
		System.out.println("Electric Car is Charging");
	}

	}

