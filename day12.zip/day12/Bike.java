package day12;

public class Bike extends vehicel {
	void KickStart()
	{
		System.out.println("Bike is Kick-Started");
	}

}
