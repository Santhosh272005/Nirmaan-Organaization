package day12;

public class Main {
	
	public static void main(String[] args) {
		ElectricCar c = new ElectricCar ();
		c.methoddrive();
		c.startengine();
		c.chargebattery();
		
		Bike b = new Bike();
		b.KickStart();
		b.startengine();
	}
	
}
