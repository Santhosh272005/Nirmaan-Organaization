package day12;

public class vehicel {
	void startengine()
	{
		System.out.println("vehicle engine started");
	}
}
